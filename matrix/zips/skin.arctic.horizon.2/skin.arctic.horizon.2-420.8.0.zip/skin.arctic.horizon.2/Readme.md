
# Arctic Horizon 2 [![License](https://img.shields.io/badge/License-GPLv3-blue)](https://github.com/jurialmunkey/skin.arctic.horizon.2/blob/master/LICENSE.txt) [![License](https://img.shields.io/badge/license-CC--NC--SA%204.0-green)](http://creativecommons.org/licenses/by-nc-sa/4.0/)

This work is licensed under Creative Commons Attribution-NonCommercial-ShareAlike 4.0 Unported License. To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/4.0/
or send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.

Icon images from iconmonstr.com see website for license terms

Classification icons sourced from wyrm65's classification icon pack
https://github.com/wyrm65/resource.images.classificationicons.colour

Language flags sourced from im85288's language flag icon pack
https://github.com/im85288/resource.images.languageflags.colour