# -*- coding: UTF-8 -*-

from resources.lib.shudder import Shudder

if __name__ == '__main__':
    Shudder()