script.module.t1mlib
================

Library of support routines for t1m addons

V4.0.4 Matrix version - added music video support
V4.0.6 - fix for Android file write having a Type Error
v4.0.7 - fix tv listings for live stream addons