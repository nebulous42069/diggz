# -*- coding: UTF-8 -*-

from resources.lib.showtime import Showtime

if __name__ == '__main__':
    Showtime()