# script.RealDebrid.vpn
This addon looks at the page https://real-debrid.com/vpn if the current ip is whitelisted or blocked for RealDebrid

# Installation in kodi:
Via repository https://peno64.github.io/repository.peno64/

Addon is installed and can be found in Add-ons under section Program add-ons
