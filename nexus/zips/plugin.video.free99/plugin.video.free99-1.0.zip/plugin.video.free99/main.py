# -*- coding: utf-8 -*-

#Credit to JewBMX for base code

from sys import argv

from resources.lib import system

system.router(argv[2])


